<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class 
{
    public $benchmark;
    public $log;
    public $config;
    public $utf8;
    public $uri;
    public $router;
    public $output;
    public $security;
    public $input;
    public $lang;
    public $session;
Welcome_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    {
        parent::__construct();
    }
}
